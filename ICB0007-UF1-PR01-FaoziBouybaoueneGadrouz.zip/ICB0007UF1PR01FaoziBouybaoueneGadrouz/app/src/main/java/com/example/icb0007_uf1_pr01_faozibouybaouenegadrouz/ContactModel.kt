package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

data class ContactModel(
    val name: String,
    val email: String,
    val phone: String,
    val website: String,
    val address: AddressModel)

data class AddressModel(
    val street: String,
    val city: String,
    val zipcode: String)

