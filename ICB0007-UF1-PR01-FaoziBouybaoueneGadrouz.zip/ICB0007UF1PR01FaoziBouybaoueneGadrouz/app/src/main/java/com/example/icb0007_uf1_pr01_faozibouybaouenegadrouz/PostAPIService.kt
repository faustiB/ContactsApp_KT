package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface PostAPIService {
    @GET("/users")
    fun getPostsFromName(): Call<List<Post>>
}