package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE

@Dao
interface ContactDAO{

    @Insert(onConflict = REPLACE)
    fun insert(contact: Contact)

//    @Insert(onConflict = REPLACE)
//    fun insertAll(array: Array<Post>)

    @Update
    fun update(contact: Contact)

    @Delete
    fun delete(contact: Contact)

    @Query("SELECT * FROM contacts")
    fun loadAllContacts(): Array<Contact>
}