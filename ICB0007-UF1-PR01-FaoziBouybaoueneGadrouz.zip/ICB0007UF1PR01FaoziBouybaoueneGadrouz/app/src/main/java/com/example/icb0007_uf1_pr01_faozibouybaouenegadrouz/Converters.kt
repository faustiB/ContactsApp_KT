package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import androidx.room.TypeConverter

class Converters{
    companion object{
        @TypeConverter
        @JvmStatic
        fun toAdress(ad_c: AddressC)/*: Address*/{

        }


        fun fromAdress(ad_c: Address)/*: AddressC*/{

        }

    }
}