package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.list_layout.view.*

class CustomAdapter (val contactList: ArrayList<ContactModel>): RecyclerView.Adapter<CustomAdapter.ViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomAdapter.ViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.list_layout, parent, false)
        return ViewHolder(v)

    }

    override fun onBindViewHolder(holder: CustomAdapter.ViewHolder, position: Int) {
        holder.bindItems(contactList[position])
    }

    override fun getItemCount(): Int {
        return contactList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems(contact: ContactModel) {
//           pasar datos a pantalla
            val tv_contactname = itemView.findViewById<TextView>(R.id.tv_contactName)
            val tv_contactemail = itemView.findViewById<TextView>(R.id.tv_contactEmail)
            tv_contactname.text = contact.name
            tv_contactemail.text = contact.email
        }


    }
}