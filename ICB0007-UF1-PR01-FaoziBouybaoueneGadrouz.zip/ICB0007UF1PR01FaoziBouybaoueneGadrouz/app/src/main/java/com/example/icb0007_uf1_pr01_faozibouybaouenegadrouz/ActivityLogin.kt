package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Database
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ActivityLogin : AppCompatActivity() {

    lateinit var user_login: String
    lateinit var password_login: String
    lateinit var contacts_list: List<Post>
    lateinit var contacts_list_pass: Array<Post>
    lateinit var contact: Contact
    lateinit var address: Address
    lateinit var db: AppDatabase
    var finishedContacts: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        bt_login.setOnClickListener {
            user_login = et_user.text.toString()
            password_login = et_password.text.toString()
            checkUserPassword(user_login, password_login)
            Thread.sleep(2000)

            if (finishedContacts) {
                val intent = Intent(this@ActivityLogin, ContactsListActivity::class.java)
                val b: Bundle = Bundle()
//                b.putSerializable("serialazable", contacts_list)
                contacts_list_pass = contacts_list.toTypedArray()
                intent.putExtra("contacts",contacts_list_pass)
                startActivity(intent)
            }
        }
    }

    fun checkUserPassword(user: String, password: String) {
        if (user != "admin" || password != "admin") {
            Toast.makeText(this, "Introduzca los datos de inicio correctos.", Toast.LENGTH_LONG)
                .show()
        } else if (user == "admin" && password == "admin") {
            db = AppDatabase.getInstance(applicationContext)!!
            GlobalScope.launch {
                //                recuperamos todos los contactos
                var contacts = db.contactDao().loadAllContacts()
//                miramos si hay contactos
                if (contacts.isEmpty()) {
//                    descargamos contactos de la API Rest
                    contacts_list = callUsersRetrofit()
//                    Recorremos la lista de contactos para ir insertandolos uno a uno en la DB
                    contacts_list.forEach {
                        //                        Creamos el contacto con los valores de la iteracion
                        address = Address(it.address.street, it.address.city, it.address.zipcode)
                        contact = Contact(it.name, it.email, it.phone, it.website, address)
                        var rowInserted = db.contactDao().insert(contact)
                        if (Integer.parseInt(rowInserted.toString()) != -1) {
                            println("New row added, row id: " + it.name)
                            finishedContacts = true
                        } else {
                            println("Something wrong")
                        }
                    }

                } else {
                    finishedContacts = true
                    contacts.forEach {
                        //                        Checkeamos en el log que la query ha funcionado correctamente.
                        println(
                            "NAME: " + it.name
                                    + "\tPHONE: " + it.phone
                                    + "\tEMAIL: " + it.email
                                    + "\tWEBSITE: " + it.website
                                    + "\tCITY: " + it.address!!.city
                                    + "\tSTREET: " + it.address!!.street
                                    + "\tZIPCODE: " + it.address!!.zipcode + "\n"
                        )

                    }
                }
            }
            Toast.makeText(this, "Contactos importados correctamente!", Toast.LENGTH_SHORT).show()
        }
    }

    fun callUsersRetrofit(): List<Post> {
//        GlobalScope.launch {
        //            val userId = "*"
        val call = getRetrofit().create(PostAPIService::class.java)
            .getPostsFromName().execute()

        val posts = call.body() as List<Post>
//        Mostramos los resultados por el log
//            posts.forEach {
//                println(
//                    "NAME: " + it.name
//                            + "\tPHONE: " + it.phone
//                            + "\tEMAIL: " + it.email
//                            + "\tWEBSITE: " + it.website
//                            + "\tCITY: " + it.address.city
//                            + "\tSTREET: " + it.address.street
//                            + "\tZIPCODE: " + it.address.zipcode + "\n"
//                )
//            }

//        }
        return posts
    }

    private fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://jsonplaceholder.typicode.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}
