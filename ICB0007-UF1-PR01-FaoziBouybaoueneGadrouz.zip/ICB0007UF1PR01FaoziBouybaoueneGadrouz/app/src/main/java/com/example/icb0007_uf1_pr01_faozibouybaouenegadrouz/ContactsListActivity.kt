package com.example.icb0007_uf1_pr01_faozibouybaouenegadrouz

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_contacts_list.*

class ContactsListActivity : AppCompatActivity() {
    val contactos: ArrayList<Contact> = ArrayList()

    lateinit var adapter :CustomAdapter

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacts_list)
        configView()
        val intent = intent
//        val contacts_list = intent.extras?.getParcelableArrayList<Post>("contacts")

        recyclerView.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)

//        Crear array list con los contactos obtenidos del intent y pasarlos al adaptader.
//        val adapter = CustomAdapter(ARRAYLIST QUE CONTENGA LOS DATOS. )

        //now adding the adapter to recyclerview
//        recyclerView.adapter = adapter
    }

    private fun configView() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}
